# My To-Do List
#### Video Demo:  <https://youtu.be/vpR5JP7xnFs?si=5WoSKSeGjQnwVx_X>
#### Description:

My name is Fatemeh and my last name is Mollaei Poli .
I'm from Bandarabbas which is located in the south of Iran .
I'm 20 years old and my major is computer engineering.

My final project is a web-based To-Do List application designed to help users manage their daily tasks in a simple and organized way.

The main idea behind this project was to create an application where users can create their own account and then manage a personal list of tasks. Each user has their own tasks, and the application keeps the tasks separated between different users.

After logging in, users can add new tasks, edit existing tasks, mark tasks as completed, delete tasks, and search for tasks. Each task can also have a description, a priority, and a deadline. The home page displays the user's tasks and also shows statistics for total tasks, completed tasks, and pending tasks.

I wanted the project to be more than just a basic list of text. For this reason, I added authentication, a database, search functionality, task statistics, priorities, deadlines, and responsive styling for different screen sizes.

## Technologies Used

I built this project using Python, Flask, SQLite, HTML, CSS, and Jinja.

Python is used for the main application logic. I used Flask as the web framework because it provides the routing and request handling needed for the different pages of the application.

SQLite is used as the database. I chose SQLite because the project is relatively small and does not need a large database server. It also works well with Flask and makes it possible to store users and tasks permanently.

HTML is used to create the structure of the web pages, while CSS is used for the visual design and layout. I also used Jinja templates so that information from the Python application and database can be displayed dynamically inside the HTML pages.

## User Authentication

One of the main parts of the project is user authentication.

Users can create an account through the Register page and then log in using their username and password. Passwords are not stored directly as plain text. Instead, the application stores a password hash in the database.

After a successful login, the user's ID is stored in the Flask session. This allows the application to know which user is currently logged in.

The session is also used to protect pages that require authentication. For example, a user who is not logged in cannot access the task management features directly.

The Logout feature clears the session and returns the user to the login flow.

## Database

The application uses a SQLite database with two main tables: users and tasks.

The users table stores information about registered users, including their ID, username, and password hash.

The tasks table stores the tasks created by users. A task contains information such as its title, description, priority, deadline, completed status, and creation time.

The tasks table also contains a user_id field. This connects each task to the user who created it.

This relationship is important because it allows the application to make sure that users only see and manage their own tasks.

## Task Management

The main purpose of the application is managing tasks.

Users can create a new task from the Add Task page. When creating a task, the user can enter a title and description, select a priority, and choose a deadline.

After the task is submitted, it is stored in the SQLite database and displayed on the home page.

Users can also edit tasks. The Edit page loads the existing information from the database and allows the user to change the title, description, priority, or deadline. After saving the changes, the updated information is stored in the database.

There is also a Complete feature. When a user completes a task, the completed status is updated in the database. This allows the application to distinguish between completed and pending tasks even after the page is refreshed.

If a task is no longer needed, the user can delete it from the database using the Delete feature.

## Search and Task Statistics

I added a search feature to make the application easier to use when there are many tasks.
The user can enter text into the search box, and the application searches for matching information in the task title or description. The results are then displayed on the home page.

The home page also contains task statistics. It shows the total number of tasks, the number of completed tasks, and the number of pending tasks.

These values are calculated from the tasks stored in the database and give the user a quick overview of their current task list.

## Templates and Layout

The project uses several HTML templates inside the templates directory.

The main templates are layout.html, index.html, login.html, register.html, add.html, and edit.html.

I used layout.html as a shared template for the common structure of the website. This includes elements such as the navigation bar and the general page layout.

The other pages extend the shared layout instead of repeating the same HTML structure on every page. This makes the project easier to organize and maintain.

Jinja is used to display information dynamically, such as the current user's tasks, task priority, deadline, and completion status.

## Styling and Responsive Design

The visual design of the application is written in static/styles.css.

I tried to keep the interface simple and easy to understand. The navigation bar provides access to the main pages, while tasks and statistics are displayed in separate sections.

I also added responsive CSS for smaller screens. This was important because the application should be usable on both a laptop and a mobile phone.

For smaller screens, the layout changes so that the content and forms fit better on the available screen width. The input fields, buttons, navigation, and task information are adjusted to make the application easier to use on mobile devices.

## Project Structure

The main files and directories are:

- app.py - contains the Flask application, routes, authentication logic, and database operations.
- schema.sql - contains the SQL commands used to create the database tables.
- templates/ - contains the HTML and Jinja templates.
- static/styles.css - contains the CSS used for the design and responsive layout.

## How to Run

To run the application, open the project directory in the CS50 development environment and use:

    flask run

Flask then provides a local URL where the application can be opened in a web browser.

The user can then register an account, log in, and start creating and managing tasks.

## Conclusion

The main goal of this project was to build a practical web application while using the concepts learned throughout CS50.

The project combines Python and Flask for the backend, SQLite for persistent data storage, HTML and Jinja for the web pages, and CSS for the visual design.

Building this application also gave me experience with user authentication, sessions, databases, SQL queries, forms, CRUD operations, search functionality, and responsive web design.

Overall, I designed the application to be simple enough to use but still include the main features that would be useful in a real To-Do List application.
